from morph.response import Response
from morph.action import GoToFlow

response = Response()
response.add_action(GoToFlow("My Conversation"))